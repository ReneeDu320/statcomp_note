#' Get a faster t-test
#'
#' This function provides a faster method to return the t-test results
#'
#' @param x a vector of numbers
#' @param f a function used to generate factors by specifying the pattern of their levels
#'
#' The rowvars function calculates the variance for each row in a matrix
#' Based on the first function, the second function returns the t-test result between x and f
#'
#' @return the t-test result between x and f
#'
#' @examples
#' m <- 400
#' n <- 50
#' little.n <- n/2
#' set.seed(1)
#' x <- matrix(rnorm(m*n),nrow=m,ncol=n)
#' f <- gl(2,little.n)
#' getT(x,f)
#'
#'
#' @importFrom gtools rdirichlet
#'
#' @export
#'
#'

getT <- function (x, f){
  rowVars <- function(x) {
    rowSums((x-rowMeans(x))^2) / (ncol(x)-1)
  }
  xbar.diff <- rowMeans(x[, which(f==1)]) - rowMeans(x[, which(f==2)])
  n1 <- sum(f==1)
  n2 <- sum(f==2)
  sp.sq <- ((n1-1)*rowVars(x[, which(f==1)])+(n2-1)*rowVars(x[, which(f==2)]))/(n1 + n2 - 2)
  ts <- xbar.diff/sqrt(sp.sq*(1/n1 + 1/n2))
  return(ts)
}
